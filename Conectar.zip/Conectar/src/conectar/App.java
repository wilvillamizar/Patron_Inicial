/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conectar;
/**
 *
 * @author w_vil
 */
public class App {
    public static void main(String[] args){
   
        //Conexion c = new Conexion();
        Conexion c;
        c = Conexion.getInstancia();
        c.Conexion();
        c.desconectar();   
        boolean rpta = c instanceof Conexion;
        System.out.println(rpta); 
    }
}
