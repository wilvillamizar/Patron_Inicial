/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conectar;
/**
 *
 * @author w_vil
 */
public class Conexion {
    
    private static Conexion instancia;
    // private static conectar instancia = new conectar;
    // Para evitar instancias mediante operador "new"
    Conexion() {

    }    
    //para obtener la instancia unicamente por este metodo
    //Notese la palabra reservada "static" hace posible el acceso mediante Clase.metodo
    public static Conexion getInstancia() {
        if (instancia == null){
            instancia = new Conexion();
        }
        return instancia;
    }
    //Metodo de prueba
    public void Conexion(){
        System.out.println("Conectado a la Base de Datos");
    }
    //Método de prueba
    public void desconectar(){
        System.out.println("Desconectado a la Base de Datos");
    }

}
